## Packages
recharts | For visualizing match scores with gauges/charts
framer-motion | For smooth animations and transitions

## Notes
API endpoints are defined in shared/routes.ts
Authentication is not currently implemented in the frontend (public access for MVP)
Resume input is text-paste based, no file upload yet
